﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Monte_seu_Xratao
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void ovofrito_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ovofritosc_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void frances_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void hamburger_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void paobatata_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void duplo_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void morango_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void batata_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void danoninho_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void catchupe_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void preparar_Click(object sender, EventArgs e)
        {
            string Resultado = "No seu X-Ratão Vai \n";
            if (frances.Checked) Resultado += frances.Text + ", \n";
            if (hamburger.Checked) Resultado += hamburger.Text + ", \n";
            if (paobatata.Checked) Resultado += paobatata.Text + ", \n";
            if (burgao.Checked) Resultado += burgao.Text + ", \n";
            if (duplo.Checked) Resultado += duplo.Text + ", \n";
            if (frango.Checked) Resultado += frango.Text + ", \n";
            if (ratao.Checked) Resultado += ratao.Text + ", \n";
            if (ovofrito.Checked) Resultado += ovofrito.Text + ", \n";
            if (ovofritoSc.Checked) Resultado += ovofritoSc.Text + ", \n";
            if (ovocodorna.Checked) Resultado += ovocodorna.Text + ", \n";
            if (Sovo.Checked) Resultado += Sovo.Text + ", \n";
            if (napolitano.Checked) Resultado += napolitano.Text + ", \n";
            if (morango.Checked) Resultado += morango.Text + ", \n";
            if (chocolate.Checked) Resultado += chocolate.Text + ", \n";
            if (baunilha.Checked) Resultado += baunilha.Text + ", \n";
            if (alface.Checked) Resultado += alface.Text + ", \n";
            if (tomate.Checked) Resultado += tomate.Text + ", \n";
            if (batata.Checked) Resultado += batata.Text + ", \n";
            if (queijoprato.Checked) Resultado += queijoprato.Text + ", \n";
            if (mussarela.Checked) Resultado += mussarela.Text + ", \n";
            if (queijoralado.Checked) Resultado += queijoralado.Text + ", \n";
            if (danoninho.Checked) Resultado += danoninho.Text + ", \n";
            if (katchupe.Checked) Resultado += katchupe.Text + ", \n";
            if (mostarda.Checked) Resultado += mostarda.Text + ", \n";
            if (tempero.Checked) Resultado += tempero.Text + ", \n";
            if (ovomaltine.Checked) Resultado += ovomaltine.Text + ", \n";
            if (condensado.Checked) Resultado += condensado.Text + ", \n";
            if (sucrilhos.Checked) Resultado += sucrilhos.Text + ", \n";
            Resultado += "e é isso!";
            MessageBox.Show(Resultado);


        }

        private void ovomaltine_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void condensado_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void burgao_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void frango_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ratao_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ovocodorna_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Sovo_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void napolitano_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chocolate_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void baunilha_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void alface_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void tomate_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void queijoprato_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void mussarela_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void queijoralado_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void mostarda_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void tempero_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void sucrilhos_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
