﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace QuizEnem
{
    public partial class questao_1 : Form
    {
        public questao_1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void prox_Click(object sender, EventArgs e)
        {


            if (AltD.Checked)
            {
                Class1.acertos += 1;
                Class1.questao1 = true;
            }
            questao_2 questao_2 = new questao_2();
            questao_2.Show();
            this.Close();
    }
    }
}
