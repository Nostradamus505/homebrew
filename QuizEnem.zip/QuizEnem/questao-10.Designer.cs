﻿namespace QuizEnem
{
    partial class questao_10
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(questao_10));
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.AltE = new System.Windows.Forms.RadioButton();
            this.AltD = new System.Windows.Forms.RadioButton();
            this.AltC = new System.Windows.Forms.RadioButton();
            this.AltB = new System.Windows.Forms.RadioButton();
            this.AltA = new System.Windows.Forms.RadioButton();
            this.prox = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("MV Boli", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(247, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(266, 49);
            this.label1.TabIndex = 1;
            this.label1.Text = "Questão - 10";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.BackgroundImage = global::QuizEnem.Properties.Resources.fundo;
            this.groupBox1.Controls.Add(this.AltE);
            this.groupBox1.Controls.Add(this.AltD);
            this.groupBox1.Controls.Add(this.AltC);
            this.groupBox1.Controls.Add(this.AltB);
            this.groupBox1.Controls.Add(this.AltA);
            this.groupBox1.Font = new System.Drawing.Font("MV Boli", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(12, 421);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(522, 188);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Alternativas";
            // 
            // AltE
            // 
            this.AltE.AutoSize = true;
            this.AltE.Location = new System.Drawing.Point(6, 138);
            this.AltE.Name = "AltE";
            this.AltE.Size = new System.Drawing.Size(97, 32);
            this.AltE.TabIndex = 4;
            this.AltE.TabStop = true;
            this.AltE.Text = "E) 36";
            this.AltE.UseVisualStyleBackColor = true;
            // 
            // AltD
            // 
            this.AltD.AutoSize = true;
            this.AltD.Location = new System.Drawing.Point(6, 110);
            this.AltD.Name = "AltD";
            this.AltD.Size = new System.Drawing.Size(99, 32);
            this.AltD.TabIndex = 3;
            this.AltD.TabStop = true;
            this.AltD.Text = "D) 24";
            this.AltD.UseVisualStyleBackColor = true;
            // 
            // AltC
            // 
            this.AltC.AutoSize = true;
            this.AltC.Location = new System.Drawing.Point(6, 83);
            this.AltC.Name = "AltC";
            this.AltC.Size = new System.Drawing.Size(91, 32);
            this.AltC.TabIndex = 2;
            this.AltC.TabStop = true;
            this.AltC.Text = "C) 18";
            this.AltC.UseVisualStyleBackColor = true;
            // 
            // AltB
            // 
            this.AltB.AutoSize = true;
            this.AltB.Location = new System.Drawing.Point(6, 57);
            this.AltB.Name = "AltB";
            this.AltB.Size = new System.Drawing.Size(91, 32);
            this.AltB.TabIndex = 1;
            this.AltB.TabStop = true;
            this.AltB.Text = "B) 12";
            this.AltB.UseVisualStyleBackColor = true;
            // 
            // AltA
            // 
            this.AltA.AutoSize = true;
            this.AltA.Location = new System.Drawing.Point(6, 30);
            this.AltA.Name = "AltA";
            this.AltA.Size = new System.Drawing.Size(84, 32);
            this.AltA.TabIndex = 0;
            this.AltA.TabStop = true;
            this.AltA.Text = "A) 6";
            this.AltA.UseVisualStyleBackColor = true;
            // 
            // prox
            // 
            this.prox.BackColor = System.Drawing.Color.DimGray;
            this.prox.BackgroundImage = global::QuizEnem.Properties.Resources.fundo;
            this.prox.Font = new System.Drawing.Font("MV Boli", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prox.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.prox.Location = new System.Drawing.Point(551, 531);
            this.prox.Name = "prox";
            this.prox.Size = new System.Drawing.Size(173, 60);
            this.prox.TabIndex = 3;
            this.prox.Text = "Proximo";
            this.prox.UseVisualStyleBackColor = false;
            this.prox.Click += new System.EventHandler(this.prox_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("MV Boli", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Image = global::QuizEnem.Properties.Resources.fundo;
            this.label2.Location = new System.Drawing.Point(12, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(570, 251);
            this.label2.TabIndex = 4;
            this.label2.Text = resources.GetString("label2.Text");
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::QuizEnem.Properties.Resources.quest10;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(599, 116);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(142, 251);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // questao_10
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::QuizEnem.Properties.Resources.Dybo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(793, 621);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.prox);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "questao_10";
            this.Text = "questao_10";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton AltE;
        private System.Windows.Forms.RadioButton AltD;
        private System.Windows.Forms.RadioButton AltC;
        private System.Windows.Forms.RadioButton AltB;
        private System.Windows.Forms.RadioButton AltA;
        private System.Windows.Forms.Button prox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}