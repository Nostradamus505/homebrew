﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizEnem
{
    public partial class questao_2 : Form
    {
        public questao_2()
        {
            InitializeComponent();
        }

        private void prox_Click(object sender, EventArgs e)
        {
            if (AltB.Checked)
            {
                Class1.acertos += 1;
                Class1.questao2 = true;
            }
            questao_3 questao_3 = new questao_3();
            questao_3.Show();
            this.Close();
        }
    }
}
