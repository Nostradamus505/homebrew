﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizEnem
{
    public partial class questao_7 : Form
    {
        public questao_7()
        {
            InitializeComponent();
        }

        private void prox_Click(object sender, EventArgs e)
        {
            if (AltA.Checked)
            {
                Class1.acertos += 1;
                Class1.questao7 = true;
            }
            questao_8 questao_8 = new questao_8();
            questao_8.Show();
            this.Close();
        }
    }
}
