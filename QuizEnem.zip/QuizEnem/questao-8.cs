﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizEnem
{
    public partial class questao_8 : Form
    {
        public questao_8()
        {
            InitializeComponent();
        }

        private void prox_Click(object sender, EventArgs e)
        {
            if (AltD.Checked)
            {
                Class1.acertos += 1;
                Class1.questao8 = true;
            }
            questao_9 questao_9 = new questao_9();
            questao_9.Show();
            this.Close();
        }
    }
}
