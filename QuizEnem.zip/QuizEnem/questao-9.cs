﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizEnem
{
    public partial class questao_9 : Form
    {
        public questao_9()
        {
            InitializeComponent();
        }

        private void prox_Click(object sender, EventArgs e)
        {
            if (AltC.Checked)
            {
                Class1.acertos += 1;
                Class1.questao9 = true;
            }
            questao_10 questao_10 = new questao_10();
            questao_10.Show();
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
