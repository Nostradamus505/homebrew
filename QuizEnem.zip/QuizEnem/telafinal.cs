﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizEnem
{
    public partial class telafinal : Form
    {
        public telafinal()
        {
            InitializeComponent();
        }
      

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void telafinal_Load_1(object sender, EventArgs e)
        {
            label2.Text = "Sua pontuação: " + Class1.acertos + " pontos";
            label3.Text = "Você errou: " + (10 - Class1.acertos) + " Questões";
            if (Class1.questao1 == false)
            {
                label4.Text += " Questão 1: Errada \n";
            }
            else
            {
                label4.Text += " Questão 1: Certa \n";
            }

            if (Class1.questao2 == false)
            {
                label4.Text += "Questão 2: Errada \n";
            }
            else
            {
                label4.Text += "Questão 2: Certa \n";
            }

            if (Class1.questao3 == false)
            {
                label4.Text += " Questão 3: Errada \n";
            }
            else
            {
                label4.Text += " Questão 3: Certa \n";
            }

            if (Class1.questao4 == false)
            {
                label4.Text += " Questão 4: Errada \n";
            }
            else
            {
                label4.Text += " Questão 4: Certa \n";
            }

            if (Class1.questao5 == false)
            {
                label4.Text += " Questão 5: Errada \n";
            }
            else
            {
                label4.Text += " Questão 5: Certa \n";
            }

            if (Class1.questao6 == false)
            {
                label5.Text += " Questão 6: Errada \n";
            }
            else
            {
                label5.Text += " Questão 6: Certa \n";
            }

            if (Class1.questao7 == false)
            {
                label5.Text += " Questão 7: Errada \n";
            }
            else
            {
                label5.Text += " Questão 7: Certa \n";
            }

            if (Class1.questao8 == false)
            {
                label5.Text += " Questão 8: Errada \n";
            }
            else
            {
                label5.Text += " Questão 8: Certa \n";
            }

            if (Class1.questao9 == false)
            {
                label5.Text += " Questão 9: Errada \n";
            }
            else
            {
                label5.Text += " Questão 9: Certa \n";
            }

            if (Class1.questao10 == false)
            {
                label5.Text += " Questão 10: Errada \n";
            }
            else
            {
                label5.Text += " Questão 10: Certa \n";
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 Form1 = new Form1();
            Form1.Close();
            this.Close();
        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 Form1 = new Form1();
            Form1.Show();
            this.Close();

        }
    }
    }

